﻿using System.Web.Mvc;

namespace Omu.ProDinner.WebUI.Controllers
{
    public class StuffController : BaseController
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}