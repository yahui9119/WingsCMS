﻿namespace Omu.ProDinner.WebUI.Dto
{
    public class ErrorDisplay
    {
        public string Message { get; set; }
    }
}